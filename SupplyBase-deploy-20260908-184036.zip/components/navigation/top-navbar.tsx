"use client";

import { useState } from "react";
import Link from "next/link";
import { Search, Menu, Settings, LogOut, User, ChevronDown, Building2, MessageSquare, UserSearch, Contact, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/shared/theme-toggle";
import { SearchBar } from "@/components/shared/search-bar";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/use-session";
import { initials } from "@/utils/format";
import { cn } from "@/lib/utils";
import { permissionForAdminHref, PORTAL_CONFIG, type PortalKey } from "@/lib/roles";
import type { SessionUser } from "@/types/auth";

const ROLE_COLORS: Record<string, string> = {
  ADMIN: "bg-orange-500/20 text-orange-500",
  SUPPLIER: "bg-blue-500/20 text-blue-500",
  BUYER: "bg-emerald-500/20 text-emerald-500",
  FREELANCER: "bg-purple-500/20 text-purple-500",
};

interface TopNavbarProps {
  user?: SessionUser | null;
  portal?: PortalKey;
  permissions?: string[];
}

export function TopNavbar({ user, portal = "admin", permissions = [] }: TopNavbarProps) {
  const { logout, isLoggingOut } = useAuth();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);
  const { navGroups: allNavGroups } = PORTAL_CONFIG[portal];
  const navGroups = allNavGroups.map((group) => ({ ...group, items: group.items.filter((item) => {
    if (portal !== "admin" || permissions.includes("*")) return true;
    const required = permissionForAdminHref(item.href);
    return !required || permissions.includes(required);
  }) })).filter((group) => group.items.length > 0);

  return (
    <header className="flex items-center justify-between h-16 px-6 border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-40">
      {/* Mobile menu trigger */}
      <Button variant="ghost" size="icon" className="md:hidden h-9 w-9" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation menu">
        <Menu className="h-4 w-4" />
      </Button>

      {/* Search */}
      {mobileSearchOpen ? (
        <div className="flex md:hidden flex-1 items-center gap-1.5">
          <SearchBar placeholder="Search suppliers, contacts, orders..." className="w-full" />
          <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={() => setMobileSearchOpen(false)} aria-label="Close search">
            <X className="h-4 w-4" />
          </Button>
        </div>
      ) : (
        <div className="hidden md:flex flex-1 max-w-md">
          <SearchBar placeholder="Search suppliers, contacts, orders..." className="w-full" />
        </div>
      )}

      {/* Mobile search icon */}
      {!mobileSearchOpen && (
        <Button variant="ghost" size="icon" className="md:hidden h-9 w-9" onClick={() => setMobileSearchOpen(true)} aria-label="Search">
          <Search className="h-4 w-4" />
        </Button>
      )}

      {/* Right actions */}
      <div className={cn("items-center gap-1", mobileSearchOpen ? "hidden md:flex" : "flex")}>
        {/* Admin-only real quick links — no dead buttons, only routes that exist. Hidden below lg; reachable via the mobile drawer instead. */}
        {user?.role === "ADMIN" && (
          <>
            <div className="hidden lg:flex items-center gap-1">
              <Button variant="outline" size="sm" className="gap-1.5" render={<Link href="/directory" />} nativeButton={false}>
                <Building2 className="h-3.5 w-3.5" /> Supplier Directory
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5" render={<Link href="/buyer-directory" />} nativeButton={false}>
                <UserSearch className="h-3.5 w-3.5" /> Buyer Directory
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5" render={<Link href="/crm" />} nativeButton={false}>
                <Contact className="h-3.5 w-3.5" /> Own Contacts
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5" render={<Link href="/crm" />} nativeButton={false}>
                <MessageSquare className="h-3.5 w-3.5" /> CRM Inbox
              </Button>
            </div>
            <Separator orientation="vertical" className="h-5 mx-1 hidden lg:block" />
          </>
        )}

        {/* Notifications */}
        <NotificationBell />

        <ThemeToggle />

        {/* Profile menu */}
        {user && (
          <>
            <Separator orientation="vertical" className="h-5 mx-1" />
            <DropdownMenu>
              <DropdownMenuTrigger render={
                <button className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-lg hover:bg-muted transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  <span />
                </button>
              }>
                <div className={cn(
                  "flex items-center justify-center w-7 h-7 rounded-full text-xs font-semibold",
                  ROLE_COLORS[user.role] ?? "bg-primary/20 text-primary"
                )}>
                  {initials(user.name)}
                </div>
                <div className="hidden sm:block text-left">
                  <p className="text-xs font-medium text-foreground leading-none">{user.name.split(" ")[0]}</p>
                  <p className="text-[10px] text-muted-foreground leading-none mt-0.5">{user.role}</p>
                </div>
                <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
              </DropdownMenuTrigger>

              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuGroup>
                  <DropdownMenuLabel className="pb-1">
                    <p className="font-medium text-foreground truncate">{user.name}</p>
                    <p className="text-xs text-muted-foreground font-normal truncate">{user.email}</p>
                  </DropdownMenuLabel>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="gap-2">
                  <User className="h-4 w-4" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem className="gap-2">
                  <Settings className="h-4 w-4" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="gap-2 text-destructive focus:text-destructive focus:bg-destructive/10"
                  onClick={logout}
                  disabled={isLoggingOut}
                >
                  <LogOut className="h-4 w-4" />
                  {isLoggingOut ? "Signing out…" : "Sign out"}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </>
        )}
      </div>

      {/* Mobile navigation drawer — mirrors the desktop sidebar's real routes. */}
      <Sheet open={mobileNavOpen} onOpenChange={setMobileNavOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetHeader className="border-b border-border">
            <SheetTitle>SupplyBase</SheetTitle>
          </SheetHeader>
          <nav className="flex-1 overflow-y-auto scrollbar-thin px-3 py-4 space-y-6">
            {navGroups.map((group) => (
              <div key={group.group}>
                <p className="px-2 mb-1.5 text-xs font-medium uppercase tracking-widest text-muted-foreground">{group.group}</p>
                <ul className="space-y-0.5">
                  {group.items.map((item) =>
                    item.comingSoon ? (
                      <li key={item.label}>
                        <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm font-medium text-muted-foreground/50">
                          <item.icon className="h-4 w-4 shrink-0" />
                          <span className="flex-1">{item.label}</span>
                          <span className="text-[10px]">Soon</span>
                        </div>
                      </li>
                    ) : (
                      <li key={item.label}>
                        <Link
                          href={item.href}
                          onClick={() => setMobileNavOpen(false)}
                          className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm font-medium text-foreground hover:bg-muted transition-colors"
                        >
                          <item.icon className="h-4 w-4 shrink-0" />
                          {item.label}
                        </Link>
                      </li>
                    )
                  )}
                </ul>
              </div>
            ))}
          </nav>
        </SheetContent>
      </Sheet>
    </header>
  );
}
